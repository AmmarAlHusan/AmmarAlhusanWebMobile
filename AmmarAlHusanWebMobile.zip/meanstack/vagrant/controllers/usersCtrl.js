const { UPDATE } = require("sequelize/types/query-types");

module.exports = {
  getAllUsers: function(req, res) {
    models.User.findAll().then(function(users) {
      res.status(200).json(users);
    });
  },

  getOneUser: function(req, res) {
    models.User.findOne({
      where: {
        id: req.params.id
      }
    }).then(function(user) {
      if (user === null) {
        res.status(404).json({ "not found": 404 });
      } else {
        res.status(200).json(user);
      }
    });
  },

  createUser: function(req, res) {
    if (req.body.firstname && req.body.lastname) {
      models.User.create({ firstname: req.body.firstname, lastname: req.body.lastname }).then(function(user) {
        res.status(201).json(user);
      });
    } else {
      res.status(500).json({ "please check your data": 500 });
    }
  },

  updateUser: function(req, res) {
    models.User.update({ firstname: req.body.firstname, lastname: req.body.lastname }, {
      where: { id: req.body.id }
    }).then(function(user) {
      if (user == 1) {
        // Gérer la réponse après la mise à jour réussie
        res.status(200).json({ message: 'User updated successfully' });
      } else {
        // Gérer le cas où la mise à jour n'a pas été effectuée (peut-être aucun utilisateur avec cet ID)
        res.status(404).json({ message: 'User not found or update failed' });
      }
    });
  },

  deleteUser: function(req, res) {
    models.User.destroy({
      where: {
        id: req.params.id
      }
    }).then(function(user) {
      if (user === 1) {
        res.status(200).json({ message: 'User deleted successfully' });
      } else {
        res.status(404).json({ message: 'User not found or delete failed' });
      }
    });
  }
};
