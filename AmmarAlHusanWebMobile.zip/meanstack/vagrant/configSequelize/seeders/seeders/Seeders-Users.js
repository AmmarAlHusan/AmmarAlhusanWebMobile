'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    try {
      await queryInterface.bulkInsert('Users', [{
        firstname: 'John',
        lastname: 'Doe',
        createdAt: new Date(),
        updatedAt: new Date()
      }], {});
    } catch (error) {
      console.error('Error inserting data:', error);
      throw error;
    }
  },
  down: async (queryInterface, Sequelize) => {
    try {
      await queryInterface.bulkDelete('Users', null, {});
    } catch (error) {
      console.error('Error deleting data:', error);
      throw error;
    }
  }
};
