
const request = require('supertest');
const app = require('../../configSequelize/seeders/models/index.js'); 

describe('User API Tests', () => {
    let createdUserId;
  
    it('should create a user', async () => {
      try {
        const userData = {
          username: 'john_doe',
          email: 'john@example.com',
          // Autres champs nécessaires pour créer un utilisateur
        };
  
        const response = await request(app)
          .post('/api/users')
          .send(userData);
  
        expect(response.statusCode).toBe(201);
        expect(response.body).toHaveProperty('_id');
        createdUserId = response.body._id;
      } catch (error) {
        throw new Error(`Erreur lors de la création de l'utilisateur : ${error.message}`);
      }
    });
  
    it('should get one user', async () => {
      try {
        if (!createdUserId) {
          throw new Error('Aucun utilisateur créé pour les tests "get one user"');
        }
  
        const response = await request(app)
          .get(`/api/users/${createdUserId}`);
  
        expect(response.statusCode).toBe(200);
        // Vérifiez d'autres propriétés de la réponse si nécessaire
      } catch (error) {
        throw new Error(`Erreur lors de la récupération de l'utilisateur : ${error.message}`);
      }
    });
  
    it('should update a user', async () => {
      try {
        if (!createdUserId) {
          throw new Error('Aucun utilisateur créé pour les tests "update user"');
        }
  
        const updatedUserData = {
          username: 'john_doe_updated',
          // Autres champs à mettre à jour
        };
  
        const response = await request(app)
          .put(`/api/users/${createdUserId}`)
          .send(updatedUserData);
  
        expect(response.statusCode).toBe(200);
        // Vérifiez si la mise à jour a été correctement effectuée si nécessaire
      } catch (error) {
        throw new Error(`Erreur lors de la mise à jour de l'utilisateur : ${error.message}`);
      }
    });
  
    it('should delete a user', async () => {
      try {
        if (!createdUserId) {
          throw new Error('Aucun utilisateur créé pour les tests "delete user"');
        }
  
        const response = await request(app)
          .delete(`/api/users/${createdUserId}`);
  
        expect(response.statusCode).toBe(204);
        // Vérifiez si l'utilisateur a été supprimé de manière appropriée
      } catch (error) {
        throw new Error(`Erreur lors de la suppression de l'utilisateur : ${error.message}`);
      }
    });
  
    // D'autres tests peuvent être ajoutés pour couvrir d'autres fonctionnalités
  });
  