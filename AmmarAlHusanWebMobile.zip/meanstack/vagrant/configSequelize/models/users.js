'use strict';
const { DataTypes, Model } = require('sequelize');

module.exports = (sequelize) => {
    class Users extends Model {
        static associate(models) {
            // Cette méthode peut être utilisée pour définir des associations avec d'autres modèles si nécessaire
        }
    }

    Users.init({
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        firstname: {
            type: DataTypes.STRING,
        },
        lastname: {
            type: DataTypes.STRING,
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW, 
            // Valeur par défaut pour le champ createdAt
            allowNull: false 
            // Assurez-vous que ce champ n'est pas null
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW, 
            // Valeur par défaut pour le champ updatedAt
            allowNull: false 
            // Assurez-vous que ce champ n'est pas null
        },
    }, {
        sequelize,
        modelName: 'Users',
    });

    return Users;
};
